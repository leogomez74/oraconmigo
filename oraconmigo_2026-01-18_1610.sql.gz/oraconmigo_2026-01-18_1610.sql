-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: oraconmigo
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bible_readings`
--

DROP TABLE IF EXISTS `bible_readings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bible_readings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `book` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chapter` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bible_readings_book_index` (`book`),
  KEY `bible_readings_created_at_index` (`created_at`),
  KEY `bible_readings_people_id_index` (`people_id`),
  CONSTRAINT `bible_readings_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bible_readings`
--

LOCK TABLES `bible_readings` WRITE;
/*!40000 ALTER TABLE `bible_readings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bible_readings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contenido`
--

DROP TABLE IF EXISTS `contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contenido` (
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `audio` tinyint(1) NOT NULL DEFAULT '0',
  `video` tinyint(1) NOT NULL DEFAULT '0',
  `texto` tinyint(1) NOT NULL DEFAULT '0',
  `musica` tinyint(1) NOT NULL DEFAULT '0',
  `imagenes` tinyint(1) NOT NULL DEFAULT '0',
  `cualquiera` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`whatsapp`),
  CONSTRAINT `contenido_whatsapp_foreign` FOREIGN KEY (`whatsapp`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contenido`
--

LOCK TABLES `contenido` WRITE;
/*!40000 ALTER TABLE `contenido` DISABLE KEYS */;
/*!40000 ALTER TABLE `contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encuesta`
--

DROP TABLE IF EXISTS `encuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encuesta` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pregunta` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opciones` json DEFAULT NULL,
  `obligatoria` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `encuesta_codigo_unique` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encuesta`
--

LOCK TABLES `encuesta` WRITE;
/*!40000 ALTER TABLE `encuesta` DISABLE KEYS */;
INSERT INTO `encuesta` VALUES (1,'tiempo_diario','¿Cuánto tiempo quieres dedicarle a tu vida de oración cada día?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"5 minutos al día\", \"10 minutos al día\", \"15 minutos al día\", \"30+ minutos al día\"]',1),(2,'momento_preferido','¿En qué momento del día prefieres orar?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Por la mañana al despertar\", \"Durante el día (mediodía)\", \"Por la tarde\", \"Por la noche antes de dormir\", \"Cualquier momento\"]',1),(3,'area_mejorar','¿Qué área te gustaría mejorar primero? (Selecciona todas las que apliquen)','2026-01-18 15:40:26','2026-01-18 15:40:26','multiple_choice','[\"Reducir el estrés\", \"Disminuir la ansiedad\", \"Mejorar el ánimo\", \"Dormir mejor\", \"Crecer espiritualmente\", \"Encontrar sentido y propósito\"]',1),(4,'nivel_estres','¿Cómo describirías tu nivel de estrés actualmente?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Muy alto\", \"Alto\", \"Moderado\", \"Bajo\", \"Muy bajo\"]',1),(5,'experiencia_oracion','¿Cuál es tu experiencia con la oración?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Soy nuevo en esto\", \"He orado algunas veces\", \"Oro ocasionalmente\", \"Oro regularmente\", \"Oro diariamente\"]',1),(6,'temas_oracion','¿Sobre qué temas te gustaría orar? (Selecciona todos los que quieras)','2026-01-18 15:40:26','2026-01-18 15:40:26','multiple_choice','[\"Salud y sanación\", \"Familia y relaciones\", \"Trabajo y finanzas\", \"Guía y dirección\", \"Gratitud\", \"Perdón\"]',1),(7,'denominacion','¿Con qué denominación cristiana te identificas?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Católico\", \"Protestante/Evangélico\", \"Ortodoxo\", \"Pentecostal\", \"Bautista\", \"Adventista\", \"Otra\"]',0),(8,'asistencia_iglesia','¿Con qué frecuencia asistes a una iglesia o comunidad de fe?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Varias veces por semana\", \"Una vez por semana\", \"Una o dos veces al mes\", \"Ocasionalmente\", \"Casi nunca\", \"Nunca\"]',0),(9,'lectura_biblia','¿Con qué frecuencia lees la Biblia?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Diariamente\", \"Varias veces por semana\", \"Una vez por semana\", \"Ocasionalmente\", \"Casi nunca\", \"Nunca\"]',0),(10,'conocimiento_biblico','¿Cómo describirías tu conocimiento de la Biblia?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Principiante (recién empiezo)\", \"Básico (conozco algunas historias)\", \"Intermedio (he leído varias partes)\", \"Avanzado (la he leído completa)\", \"Experto (la estudio profundamente)\"]',0),(11,'sistema_apoyo','¿Cuántas personas pueden apoyarte en momentos difíciles?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"3 o más\", \"2 personas\", \"1 persona\", \"Solo yo\"]',1),(12,'estado_civil','¿Cuál es tu estado civil?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Soltero/a\", \"En una relación\", \"Casado/a\", \"Divorciado/a\", \"Viudo/a\", \"Prefiero no decir\"]',0),(13,'tiene_hijos','¿Tienes hijos?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Sí, menores de edad\", \"Sí, mayores de edad\", \"Sí, de ambas edades\", \"No tengo hijos\", \"Prefiero no decir\"]',0),(14,'genero','¿Cuál es tu género? (Esto nos ayuda a personalizar el contenido)','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"Hombre\", \"Mujer\", \"Prefiero no decir\"]',0),(15,'grupo_edad','¿Cuál es tu grupo de edad?','2026-01-18 15:40:26','2026-01-18 15:40:26','radio','[\"13-17\", \"18-24\", \"25-34\", \"35-44\", \"45-54\", \"55+\"]',0),(16,'formato_preferido','¿Qué formato de contenido prefieres?','2026-01-18 15:40:26','2026-01-18 15:40:26','multiple_choice','[\"Audio guiado\", \"Texto para leer\", \"Video\", \"Música de fondo\", \"Imágenes inspiradoras\", \"Cualquiera\"]',1);
/*!40000 ALTER TABLE `encuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encuesta_progreso`
--

DROP TABLE IF EXISTS `encuesta_progreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encuesta_progreso` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paso_actual` int NOT NULL DEFAULT '1' COMMENT 'Paso en el que está actualmente (1-4)',
  `ultimo_paso_completado` int NOT NULL DEFAULT '0' COMMENT 'Último paso que envió completamente (0-4)',
  `ultima_pregunta_vista` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID de la última pregunta que vio',
  `preguntas_respondidas` json DEFAULT NULL COMMENT 'Array de IDs de preguntas respondidas',
  `respuestas_parciales` json DEFAULT NULL COMMENT 'Todas las respuestas hasta el momento',
  `estado` enum('sin_iniciar','en_progreso','completada','abandonada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_iniciar',
  `completada` tinyint(1) NOT NULL DEFAULT '0',
  `ultima_interaccion_at` timestamp NULL DEFAULT NULL COMMENT 'Última vez que interactuó con la encuesta',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `encuesta_progreso_people_id_unique` (`people_id`),
  KEY `encuesta_progreso_estado_index` (`estado`),
  KEY `encuesta_progreso_paso_actual_index` (`paso_actual`),
  KEY `encuesta_progreso_completada_index` (`completada`),
  KEY `encuesta_progreso_ultima_interaccion_at_index` (`ultima_interaccion_at`),
  CONSTRAINT `encuesta_progreso_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encuesta_progreso`
--

LOCK TABLES `encuesta_progreso` WRITE;
/*!40000 ALTER TABLE `encuesta_progreso` DISABLE KEYS */;
/*!40000 ALTER TABLE `encuesta_progreso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_12_31_000001_create_people_table',1),(5,'2025_12_31_000002_create_encuesta_table',1),(6,'2025_12_31_000004_add_password_to_people_table',1),(7,'2025_12_31_204331_create_personal_access_tokens_table',1),(8,'2025_12_31_210214_create_otp_codes_table',1),(9,'2025_12_31_210852_remove_password_from_people_table',1),(10,'2025_12_31_222951_create_respuestas_table',1),(11,'2026_01_03_004325_create_sessions_table',1),(12,'2026_01_08_172537_add_is_admin_to_people_table',1),(13,'2026_01_08_223007_create_bible_readings_table',1),(14,'2026_01_09_004929_create_oraciones_table',1),(15,'2026_01_09_011151_create_oracion_usuario_table',1),(16,'2026_01_10_193311_add_video_url_to_oraciones_table',1),(17,'2026_01_12_000001_create_encuesta_progreso_table',1),(18,'2026_01_14_155149_agregate_columns_to_table_encuesta',1),(19,'2026_01_16_132302_split_name_into_two_fields_people',1),(20,'2026_01_16_134019_change_primary_key_to_telefono_in_people_table',1),(21,'2026_01_16_142122_make_apellido_nunnable',1),(22,'2026_01_16_174829_restructure_respuestas_table',1),(23,'2026_01_17_000001_add_codigo_to_encuesta_table',1),(24,'2026_01_17_190000_normalize_respuestas_profile_tables',1),(25,'2026_01_18_000001_add_tipo_and_clave_hash_to_people_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objetivos`
--

DROP TABLE IF EXISTS `objetivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `objetivos` (
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estres` tinyint(1) NOT NULL DEFAULT '0',
  `ansiedad` tinyint(1) NOT NULL DEFAULT '0',
  `animo` tinyint(1) NOT NULL DEFAULT '0',
  `crecer` tinyint(1) NOT NULL DEFAULT '0',
  `sentido` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`whatsapp`),
  CONSTRAINT `objetivos_whatsapp_foreign` FOREIGN KEY (`whatsapp`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objetivos`
--

LOCK TABLES `objetivos` WRITE;
/*!40000 ALTER TABLE `objetivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `objetivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oracion_usuario`
--

DROP TABLE IF EXISTS `oracion_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oracion_usuario` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `people_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oracion_id` bigint unsigned NOT NULL,
  `completada_at` timestamp NULL DEFAULT NULL,
  `progreso` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oracion_usuario_people_id_oracion_id_unique` (`people_id`,`oracion_id`),
  KEY `oracion_usuario_oracion_id_index` (`oracion_id`),
  KEY `oracion_usuario_completada_at_index` (`completada_at`),
  KEY `oracion_usuario_people_id_index` (`people_id`),
  CONSTRAINT `oracion_usuario_oracion_id_foreign` FOREIGN KEY (`oracion_id`) REFERENCES `oraciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `oracion_usuario_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oracion_usuario`
--

LOCK TABLES `oracion_usuario` WRITE;
/*!40000 ALTER TABLE `oracion_usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `oracion_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oraciones`
--

DROP TABLE IF EXISTS `oraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oraciones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `contenido_texto` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `audio_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duracion` int DEFAULT NULL,
  `es_premium` tinyint(1) NOT NULL DEFAULT '0',
  `orden` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oraciones_categoria_index` (`categoria`),
  KEY `oraciones_es_premium_index` (`es_premium`),
  KEY `oraciones_orden_index` (`orden`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oraciones`
--

LOCK TABLES `oraciones` WRITE;
/*!40000 ALTER TABLE `oraciones` DISABLE KEYS */;
INSERT INTO `oraciones` VALUES (1,'Padre Nuestro','Tradicional','La oración que Jesús enseñó a sus discípulos','Padre nuestro que estás en el cielo,\nsantificado sea tu Nombre;\nvenga a nosotros tu reino;\nhágase tu voluntad\nen la tierra como en el cielo.\n\nDanos hoy nuestro pan de cada día;\nperdona nuestras ofensas,\ncomo también nosotros perdonamos\na los que nos ofenden;\nno nos dejes caer en la tentación,\ny líbranos del mal.\n\nAmén.',NULL,NULL,60,0,1,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(2,'Oración de la Mañana','Mañana','Comienza tu día con gratitud y esperanza','Señor, te doy gracias por este nuevo día que me regalas.\nGracias por el descanso de la noche y por la luz que ilumina mi camino.\n\nTe pido que me acompañes en cada momento de este día.\nDame fuerzas para enfrentar los desafíos,\nsabiduría para tomar buenas decisiones,\ny amor para compartir con quienes me rodean.\n\nQue cada acción que realice hoy sea para tu gloria\ny que pueda ser un instrumento de tu paz.\n\nAmén.',NULL,NULL,90,0,2,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(3,'Oración de Gratitud','Gratitud','Agradece por las bendiciones de tu vida','Padre celestial, hoy quiero darte gracias.\n\nGracias por mi vida, por mi salud, por mi familia.\nGracias por las oportunidades que me das cada día.\nGracias por tu amor incondicional que nunca me falta.\n\nAyúdame a reconocer tus bendiciones en cada momento,\nincluso en las dificultades que me ayudan a crecer.\n\nDame un corazón agradecido que sepa valorar\ntodo lo que tengo y que pueda compartir\nesa gratitud con los demás.\n\nAmén.',NULL,NULL,75,0,3,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(4,'Oración de la Noche','Noche','Termina tu día en paz y descanso','Señor, al finalizar este día vengo a ti.\n\nGracias por todo lo vivido hoy:\npor los momentos de alegría y los de aprendizaje.\n\nTe pido perdón por mis errores\ny te entrego todas mis preocupaciones.\n\nProtege mi descanso esta noche.\nCuida de mi familia y de todos mis seres queridos.\n\nQue tu paz llene mi corazón\ny pueda despertar mañana renovado\npara servirte mejor.\n\nAmén.',NULL,NULL,80,0,4,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(5,'Oración por la Paz','Paz','Pide paz para tu corazón y para el mundo','Señor, Príncipe de la Paz,\n\nTe pido paz para mi corazón,\nque está lleno de preocupaciones y ansiedades.\n\nTe pido paz para mi familia,\npara que el amor reine en nuestro hogar.\n\nTe pido paz para mi comunidad,\npara que la justicia y la compasión prevalezcan.\n\nTe pido paz para el mundo entero,\npara que cesen las guerras y divisiones.\n\nHazme un instrumento de tu paz,\ndonde haya odio, que lleve amor;\ndonde haya ofensa, que lleve perdón;\ndonde haya duda, que lleve fe.\n\nAmén.',NULL,NULL,100,0,5,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(6,'Oración por Sanación Interior','Sanación','Encuentra sanación para heridas del alma','Padre amoroso, sanador de cuerpos y almas,\n\nVengo a ti con mi corazón herido,\ncon dolores que solo tú conoces en profundidad.\n\nSana mis heridas emocionales,\nlas que vienen de mi pasado y las que cargo hoy.\n\nRestaura mi confianza cuando me siento quebrado.\nRenueva mi esperanza cuando todo parece oscuro.\nFortalece mi fe cuando las dudas me asaltan.\n\nSana mi relación conmigo mismo:\nayúdame a perdonarme,\na aceptarme,\na amarme como tú me amas.\n\nSana mis relaciones con los demás:\ndame la gracia de perdonar a quienes me han herido\ny el valor de pedir perdón a quienes he lastimado.\n\nSana todo aquello que me impide vivir en plenitud,\ny llena cada espacio sanado con tu amor y tu paz.\n\nConfío en tu poder sanador\ny acepto tu voluntad en mi vida.\n\nAmén.',NULL,NULL,180,1,6,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(7,'Oración en Momentos de Ansiedad','Paz','Encuentra calma cuando la ansiedad te invade','Señor, mi corazón está agitado.\nLos pensamientos dan vueltas en mi mente\ny la ansiedad me quita la paz.\n\nTe entrego ahora mismo todas mis preocupaciones:\n(Toma un momento para nombrar específicamente lo que te preocupa)\n\nRespiro profundamente tu presencia.\nInhalo tu paz... Exhalo mi ansiedad.\n\nTu palabra dice \"No se angustien por nada\",\ny confío en tu promesa.\n\nAyúdame a enfocarme en el presente,\nen este momento que es el único que tengo.\n\nMañana traerá sus propios afanes,\npero hoy elijo confiar en ti.\n\nCalma la tormenta en mi interior.\nDame serenidad para aceptar lo que no puedo cambiar,\nvalor para cambiar lo que sí puedo,\ny sabiduría para reconocer la diferencia.\n\nQue tu paz, que sobrepasa todo entendimiento,\nguarde mi corazón y mis pensamientos.\n\nRespiro... y descanso en ti.\n\nAmén.',NULL,NULL,150,1,7,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(8,'Oración por Fortaleza','Fortaleza','Recibe fuerza divina en momentos de debilidad','Padre todopoderoso, fuente de toda fortaleza,\n\nReconozco que mis fuerzas se han agotado.\nMe siento débil, cansado, sin ánimo para continuar.\n\nPero tu palabra promete que los que esperan en ti\nrenovarán sus fuerzas,\nlevantarán alas como las águilas,\ncorrerán y no se cansarán,\ncaminarán y no se fatigarán.\n\nHoy reclamo esa promesa para mi vida.\n\nDame fortaleza física cuando mi cuerpo está agotado.\nDame fortaleza emocional cuando mis sentimientos me abruman.\nDame fortaleza espiritual cuando mi fe vacila.\n\nRecuérdame que tu poder se perfecciona en mi debilidad,\ny que puedo hacer todas las cosas a través de Cristo\nque me fortalece.\n\nNo permitas que me rinda.\nAyúdame a levantarme una vez más,\na dar un paso más,\na creer una vez más.\n\nSé mi roca, mi fortaleza, mi refugio.\n\nEn ti encuentro la fuerza que necesito\npara enfrentar cualquier desafío.\n\nAmén.',NULL,NULL,160,1,8,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(9,'Oración por Sabiduría','Sabiduría','Pide discernimiento para tomar decisiones','Padre sabio, fuente de toda sabiduría y entendimiento,\n\nVengo a ti porque necesito dirección.\nTengo decisiones importantes que tomar\ny no sé qué camino seguir.\n\nTu palabra dice que si alguno tiene falta de sabiduría,\nla pida a ti, y tú la darás abundantemente.\n\nHoy te pido esa sabiduría.\n\nIlumina mi mente para ver con claridad.\nGuía mis pensamientos hacia lo que es verdadero y bueno.\nAyúdame a discernir entre las muchas voces que escucho.\n\nDame sabiduría para conocer tu voluntad,\nno solo para esta decisión específica,\nsino para toda mi vida.\n\nEnséñame a buscar consejo sabio\ny a reconocerlo cuando lo escuche.\n\nAyúdame a ser paciente,\na no apresurarme en mis decisiones,\ny a confiar en que tú me guiarás en el tiempo perfecto.\n\nQue tu Espíritu Santo sea mi consejero,\niluminando cada paso de mi camino.\n\nConfío en que me darás la sabiduría que necesito,\nporque tú eres fiel a tus promesas.\n\nAmén.',NULL,NULL,140,1,9,'2026-01-18 15:40:26','2026-01-18 15:40:26'),(10,'Oración por la Familia','Familia','Bendice y protege a tu familia','Padre celestial, creador de la familia,\n\nTe presento hoy a mi familia,\ncada uno de sus miembros que amo profundamente.\n\nBendice nuestro hogar.\nQue sea un lugar de amor, paz y seguridad.\nUn refugio donde cada uno pueda ser él mismo\ny sentirse aceptado y valorado.\n\nProtege a cada miembro de mi familia:\n(Nombra a cada persona específicamente)\n\nFortalece los lazos que nos unen.\nAyúdanos a comunicarnos con amor y respeto.\nEnséñanos a perdonarnos rápidamente\ny a celebrar juntos las alegrías de la vida.\n\nCuando vengan tiempos difíciles,\nmantennos unidos.\nAyúdanos a apoyarnos mutuamente,\na ser pacientes con las debilidades de cada uno,\ny a celebrar las fortalezas.\n\nBendice especialmente a:\n[los niños, para que crezcan en sabiduría y amor]\n[los jóvenes, para que encuentren su camino]\n[los adultos, para que tengan sabiduría y paciencia]\n[los ancianos, para que sean honrados y cuidados]\n\nQue nuestra familia sea un reflejo de tu amor\ny que podamos transmitir valores eternos\nde generación en generación.\n\nAmén.',NULL,NULL,190,1,10,'2026-01-18 15:40:26','2026-01-18 15:40:26');
/*!40000 ALTER TABLE `oraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_codes`
--

DROP TABLE IF EXISTS `otp_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_codes_email_index` (`email`),
  KEY `otp_codes_email_code_index` (`email`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_codes`
--

LOCK TABLES `otp_codes` WRITE;
/*!40000 ALTER TABLE `otp_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cliente',
  `estado_civil` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hijos` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edad` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `clave_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`whatsapp`),
  UNIQUE KEY `people_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES ('Administrador',NULL,'admin@ORA.app','Argentina','cliente',NULL,NULL,NULL,NULL,'+5491112345678',1,'2026-01-18 15:40:26','2026-01-18 15:40:26',NULL);
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuestas`
--

DROP TABLE IF EXISTS `respuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respuestas` (
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minutosaldia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horadeorar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estresactual` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experiencia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `denominacion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frecuenciaiglesia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frecuenciabiblia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conocimiento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apoyos` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`whatsapp`),
  CONSTRAINT `respuestas_whatsapp_foreign` FOREIGN KEY (`whatsapp`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuestas`
--

LOCK TABLES `respuestas` WRITE;
/*!40000 ALTER TABLE `respuestas` DISABLE KEYS */;
/*!40000 ALTER TABLE `respuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('24fja7gDbeBzfQ0eXOpjkEimo8FUiH7TFKG03lZr',NULL,'189.225.151.47','Mozilla/5.0 (Linux; Android 14; ALT-LX3 Build/HONORALT-L33; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/143.0.7499.143 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/543.0.0.55.73;IABMV/1;]','YTozOntzOjY6Il90b2tlbiI7czo0MDoieXlUbEN3ak5IcEVLM25ubkZHSFV3eU1TY25rQWZPYU1UT2ZSQm9DcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTA6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9zYW5jdHVtL2NzcmYtY29va2llIjtzOjU6InJvdXRlIjtzOjE5OiJzYW5jdHVtLmNzcmYtY29va2llIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768751199),('8w1PqL4m7M5BnlwX5KqWqn6JvTNxGqWG1m8JoYPZ',NULL,'84.254.106.197','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiemZjUDQ2NTU1enBsVlFsdE9aNHphblZRZnQyN2Z2eFVzbTRmRmNkMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768751663),('dyyLe4EEqjgvSVsK5dnYpRgOCgfpBO68xopjMyLJ',NULL,'201.207.176.196','curl/8.17.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoid0l5aXJneDhjSTZ6QlNKN2J1cmNDenhNbTdieml1NFpqMGJVc2JOeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1768751441),('juFXR0ExSdn0TvDDW2obEwgRYbknRHljeymJV6zw',NULL,'201.207.176.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.108.1 Chrome/142.0.7444.235 Electron/39.2.7 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiS2YyMFpyaWVCOTJCelA0d0Y0dGZDT0tOZ1luWnk0VnVBUjMxMm5uUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1768751423),('kQ6svoEGNv5fTiCIbz0AckV4EB1jjmd7l5Z6Epx0',NULL,'201.207.176.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.108.1 Chrome/142.0.7444.235 Electron/39.2.7 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmhZR1dVUUpuUmF2R0wzMG9XZ2RMdkRKVmlXMDhPM0Y3V3RCUjRNMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768751423),('NQTyNRbfK8OvkvurYyJnvWtth16cpe2w0PDH5rRG',NULL,'154.212.6.93','Mozilla/5.0 (Linux; Android 16; SM-A156U1 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/143.0.7499.143 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/543.0.0.55.73;IABMV/1;]','YTozOntzOjY6Il90b2tlbiI7czo0MDoicUsxbTNwU0F3WEk0NDR0UDVKWVBZd1lhaTNRb3pFb2liV0Z6Vk5GcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTA6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9zYW5jdHVtL2NzcmYtY29va2llIjtzOjU6InJvdXRlIjtzOjE5OiJzYW5jdHVtLmNzcmYtY29va2llIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768751416),('OJhSYh9nhqFO2PqyrPMYLGaw7msYIlaiR2J11qCR',NULL,'189.203.231.59','Mozilla/5.0 (Linux; Android 12; SM-M135M Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/143.0.7499.192 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/543.0.0.55.73;IABMV/1;]','YTozOntzOjY6Il90b2tlbiI7czo0MDoia1F4NHFnYTZtQlphQmtnMjNCT3d6ems5Y08zNmJWRHd5UmhBNmpOTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTA6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9zYW5jdHVtL2NzcmYtY29va2llIjtzOjU6InJvdXRlIjtzOjE5OiJzYW5jdHVtLmNzcmYtY29va2llIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768752392),('tQX5ygc3AmL4KLkVd3qvJlBRHabHqGerardtSvzA',NULL,'201.207.176.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR25xcjRZc1JPMU9HRTJOVkRhSXlHSDNzemhmWXhPc0lQMHZ5VGJyVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vYmFja2VuZC5vcmFjb25taWdvLmFwcC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1768751461);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temas`
--

DROP TABLE IF EXISTS `temas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temas` (
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salud` tinyint(1) NOT NULL DEFAULT '0',
  `familia` tinyint(1) NOT NULL DEFAULT '0',
  `trabajo` tinyint(1) NOT NULL DEFAULT '0',
  `paz` tinyint(1) NOT NULL DEFAULT '0',
  `guia` tinyint(1) NOT NULL DEFAULT '0',
  `gratitud` tinyint(1) NOT NULL DEFAULT '0',
  `perdon` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`whatsapp`),
  CONSTRAINT `temas_whatsapp_foreign` FOREIGN KEY (`whatsapp`) REFERENCES `people` (`whatsapp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temas`
--

LOCK TABLES `temas` WRITE;
/*!40000 ALTER TABLE `temas` DISABLE KEYS */;
/*!40000 ALTER TABLE `temas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'oraconmigo'
--

--
-- Dumping routines for database 'oraconmigo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-18 16:10:09
